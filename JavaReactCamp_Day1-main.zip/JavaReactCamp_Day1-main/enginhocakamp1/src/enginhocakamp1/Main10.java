package enginhocakamp1;

public class Main10 {

	public static void main(String[] args) {
		
		char grade = 'A';
		
		switch(grade) {
			case 'A' :
				System.out.println("Mükemmel : Geçtiniz");
				break;
			
			case 'B':
				System.out.println("Çok güzel : Geçtiniz");
				break;
				
			case 'C':
				System.out.println("İyi : Geçtiniz");
				break;
				
			case 'D':
				System.out.println("Fena Değil : Geçtiniz");
				break;
				
			case 'F':
				System.out.println("Malasef kaldınız");
				break;
				
			default:
				System.out.println("Geçersiz not girdiniz");
				
		}

	}

}
