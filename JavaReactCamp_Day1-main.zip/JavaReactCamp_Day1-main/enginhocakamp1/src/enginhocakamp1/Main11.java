package enginhocakamp1;

public class Main11 {

	public static void main(String[] args) {
		for (int i = 0; i < 10; i=i+1) {
			System.out.println(i);
		}
		System.out.println("Döngü bitti");
		
		//1'den 10'a kadar tek sayıları yazdırmak için;
		for (int i = 0; i < 10; i++) {
			if (i%2 != 0) {
				System.out.println(i);
			}
		}

	}

}
