package enginhocakamp1;

public class Main5 {
	
	public static void main(String[] args) {
		System.out.println("Merhaba JAVA");
		System.out.println("Merhaba JAVA 2");
	}
}
