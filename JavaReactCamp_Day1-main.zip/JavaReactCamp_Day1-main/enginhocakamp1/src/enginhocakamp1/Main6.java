package enginhocakamp1;

public class Main6 {

	public static void main(String[] args) {
		//case sensitive = Büyük küçük harf duyarlılığıdır.
		//Değişken tanımlarken camelCasing kullanılır.
		//reusability = tekrar tekrar kullanılabilirlik
		
		int ogrenciSayisi = 12;
		String mesaj = "Öğrenci sayısı : ";
		System.out.println(mesaj + ogrenciSayisi);
		

	}

}
