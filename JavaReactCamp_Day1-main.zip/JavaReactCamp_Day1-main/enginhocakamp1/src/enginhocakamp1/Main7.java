package enginhocakamp1;

public class Main7 {

	public static void main(String[] args) {
		
		double sayi = 12.5;
		sayi = -128;

		char karakter = 'A';
		boolean dogruMu = false;
		
		
	}

}
