package enginhocakamp1;

public class Main8 {

	public static void main(String[] args) {
		int sayi = 30;
		if (sayi<20) {
			System.out.println("Sayı 20'den küçüktür");
		}else if(sayi==20){
			System.out.println("Sayı 20'ye eşittir");
		}else {
			System.out.println("Sayı 20'den büyüktür.");
		}

	}

}
