package methodOverloading;

public class Main {

	public static void main(String[] args) {
		
		DortIslem dortIslem = new DortIslem();
		System.out.println(dortIslem.topla(3, 5));
		System.out.println(dortIslem.topla(5, 6, 9));

	}

}
