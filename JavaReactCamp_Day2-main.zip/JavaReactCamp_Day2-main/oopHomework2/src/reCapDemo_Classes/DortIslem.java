package reCapDemo_Classes;

public class DortIslem {

	public double Topla(int sayi1, int sayi2) {
		return sayi1 + sayi2;
	}
	public double Cikar(int sayi1, int sayi2) {
		return sayi1 - sayi2;
	}
	public double Carp(int sayi1, int sayi2) {
		return sayi1 * sayi2;
	}
	public double Bol(int sayi1, int sayi2) {
		return sayi1 / sayi2;
	}
}
