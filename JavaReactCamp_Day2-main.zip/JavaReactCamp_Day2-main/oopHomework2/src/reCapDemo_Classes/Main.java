package reCapDemo_Classes;

public class Main {

	public static void main(String[] args) {
		
		DortIslem dortIslem = new DortIslem();
		double sonuc = dortIslem.Carp(7, 8);
		System.out.println(sonuc);
				
	}
}
